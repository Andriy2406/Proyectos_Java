
import java.sql.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author User
 */
public class CAlumnos {
    
    int codigo;
    String nombreAlumno;
    String apellidosAlumno;

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public String getNombreAlumno() {
        return nombreAlumno;
    }

    public void setNombreAlumno(String nombreAlumno) {
        this.nombreAlumno = nombreAlumno;
    }

    public String getApellidosAlumno() {
        return apellidosAlumno;
    }

    public void setApellidosAlumno(String apellidosAlumno) {
        this.apellidosAlumno = apellidosAlumno;
    }
    
    public void MostrarAlumnos(JTable paramTablaTotalAlumnos){
    
        CConexion objetoConexion = new CConexion();
        
        
        DefaultTableModel modelo = new DefaultTableModel();
        
        String sql ="";
        
        modelo.addColumn("Id");
        modelo.addColumn("Nombres");
        modelo.addColumn("Apellidos");
        
        paramTablaTotalAlumnos.setModel(modelo);
        
        sql="select * from Alumnos;";
        
        String  [] datos = new String [3];
        Statement st;  
        
            try {
                st = objetoConexion.establecerConexion().createStatement();
                
                ResultSet rs =st.executeQuery(sql);
                
                while (rs.next()) {
                    
                    
                    datos[0] = rs.getString(1);
                    datos[1] = rs.getString(2);
                    datos[2] = rs.getString(3);
                    
                    modelo.addRow(datos);
                    
                }
                
                paramTablaTotalAlumnos.setModel(modelo);
                
            } catch (Exception e) {
                
                JOptionPane.showMessageDialog(null, "ERROR: "+ e.toString());
            }
            
            
    }
    
    
    public void insertarAlumno(JTextField paramCodigo, JTextField paramNombres, JTextField paramApellidos){
        
        setCodigo(Integer.parseInt(paramCodigo.getText()));
        setNombreAlumno(paramNombres.getText());
        setApellidosAlumno(paramApellidos.getText());
        
        CConexion objetoConexion = new CConexion();
        
        String consulta = "insert into Alumnos (id,nombres,apellidos) values (?,?, ?);";
        
        try {
            
            CallableStatement cs = objetoConexion.establecerConexion().prepareCall(consulta);
            cs.setInt(1, getCodigo());
            cs.setString(2, getNombreAlumno());
            cs.setString(3, getApellidosAlumno());
            
            cs.execute();
            
            JOptionPane.showMessageDialog(null, "Se insertó correctamente");
            
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "ERROR: "+ e.toString());
        }
    }
    
    public void SeleccionarAlumno(JTable paramTablaAlumno, JTextField paramCodigo, JTextField paramNombres, JTextField paramApellidos){
        
        try {
            
            int fila = paramTablaAlumno.getSelectedRow();
            
            if (fila>=0) {
                
                paramCodigo.setText(paramTablaAlumno.getValueAt(fila, 0).toString());
                paramNombres.setText(paramTablaAlumno.getValueAt(fila, 1).toString());
                paramApellidos.setText(paramTablaAlumno.getValueAt(fila, 2).toString());
                
                
            }
            
            else 
            {
                JOptionPane.showMessageDialog(null, "Fila no seleccionada");
                
            }
            
        } catch (Exception e) {
            
            JOptionPane.showMessageDialog(null, "ERROR: "+ e.toString());
        }
    
    }
    
    
    public void modificarAlumno(int idOriginal,JTextField paramCodigo, JTextField paramNombres, JTextField paramApellidos){
        
        setCodigo(Integer.parseInt(paramCodigo.getText()));
        setNombreAlumno(paramNombres.getText());
        setApellidosAlumno(paramApellidos.getText());
        
        CConexion objetoConexion = new CConexion();
        
        String consulta = "update Alumnos set id = ?, nombres = ?, apellidos = ? where Alumnos.id = ?;";
        
        try {
            
            PreparedStatement ps = objetoConexion.establecerConexion().prepareStatement(consulta);
            ps.setInt(1, getCodigo());
            ps.setString(2, getNombreAlumno());
            ps.setString(3, getApellidosAlumno());
            ps.setInt(4, idOriginal);
            
            int filasAfectadas = ps.executeUpdate();
            
            if (filasAfectadas > 0) {
                
                JOptionPane.showMessageDialog(null, "Se modificó correctamente");
                
            } else {
                JOptionPane.showMessageDialog(null, "No se encontró el alumno con el ID original.");
            }
            
            
            
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "ERROR: "+ e.toString());
        }
    }
    
    public void eliminarAlumno(JTextField paramCodigo){
        
        setCodigo(Integer.parseInt(paramCodigo.getText()));
   
        
        CConexion objetoConexion = new CConexion();
        
        String consulta = "delete from Alumnos where Alumnos.id = ?;";
        
        try {
            
            CallableStatement cs = objetoConexion.establecerConexion().prepareCall(consulta);
            cs.setInt(1, getCodigo());
            
            cs.execute();
            
            JOptionPane.showMessageDialog(null, "Se eliminó correctamente");
            
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "ERROR: "+ e.toString());
        }
    }
}
