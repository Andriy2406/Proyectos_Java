#pip install fastapi
#python -m pip install fastapi
#pip install uvicorn
#python -m pip install "uvicorn[standard]"
#python -m uvicorn main:app --reload
from fastapi import FastAPI

app = FastAPI()
@app.get("/")
def mostar():
    return{"mensaje":"Mi api esta lista aqui"}




