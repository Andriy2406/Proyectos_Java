#importar la clase fastapi
#es el motor que nos permite crear las APIs web
from fastapi import FastAPI

#creamos la instancia de la aplicacion
#esta variable 'app' es la que va a utilizar el servidor para ejecutar la API
app = FastAPI()

#definimos la ruta raiz con el decorador get
#esto significa que esta funcion responde a solicitudes get
#en la url raiz ("/")
@app.get("/")



#se crea la funcion que se ejecutara cuando alguien visite el direcctorio raiz 
#direcctorio raiz en el sitio web (cliente/mascota/producto  )
#esta funcion se puede personaliza para devolver la informacion 
#que el usuario necesite  
def inicio():
    return{"texto": "Informacion en la raiz de la pagina"}
 
@app.get("/cliente")
def cliente():
    return[{
         "id":123,
         "nombre":"fernanda",
         "edad":20

    },]
{
    }
@app.get("/productos")
def productos():
    return{
        "codigo":2127,
        "nombre": "papas fritas",
        "precio": 3200,
        "cantidad":2
    }
@app.get("/mascota")
def mascota():
    return[{
        "nombre":"lupe",
        "raza": "pincher",
        "edad": 10
    },
    {
          "nombre":"walter",
          "raza": "pitbull",
         "edad": 9
    }]
@app.get("/juguetes")
def juguetes ():
    return [{
        "codigo":2127,
        "nombre": "carros",
        "precio": 10000,
        "cantidad":4,
    },
    {
        "nombre": "barbie", 
        "precio": 25000,
        "cantidad":6
    }]
@app.get("/celular")
def celular():
    return[{
        "marca":"iphone 11",
        "precio": 1000000,
        "color": "negro"
    },
    {
        "marca":"iphone 13",
        "precio": 2500000,
        "color": "blanco"
    }]